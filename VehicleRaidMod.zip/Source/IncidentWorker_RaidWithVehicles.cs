using RimWorld;
using Verse;
using System.Linq;

public class IncidentWorker_RaidWithVehicles : IncidentWorker_RaidEnemy
{
    protected override bool TryExecuteWorker(IncidentParms parms)
    {
        base.TryExecuteWorker(parms);

        PawnGroupMakerUtility.GeneratePawns(
            new PawnGroupMakerParms
            {
                faction = parms.faction,
                points = parms.points * 0.3f,
                groupKind = PawnGroupKindDefOf.Combat
            }, true).ToList().ForEach(p =>
            {
                var vehicle = ThingMaker.MakeThing(ThingDef.Named("RaiderVehicle"));
                GenSpawn.Spawn(vehicle, p.Position, p.Map);
            });

        return true;
    }
}
